<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 3.5
 */

?>
<script type="text/html" id="tmpl-fusion_form_honeypot-shortcode">
	<div class="fusion-builder-placeholder-preview">
		<i class="{{ icon }}" aria-hidden="true"></i> {{ label }}
	</div>
</script>
