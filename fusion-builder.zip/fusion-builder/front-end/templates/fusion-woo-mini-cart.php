<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 3.8
 */

?>
<script type="text/html" id="tmpl-fusion_woo_mini_cart-shortcode">
	<div {{{ _.fusionGetAttributes( wrapperAttr ) }}}>
		{{{output}}}
	</div>
</script>
