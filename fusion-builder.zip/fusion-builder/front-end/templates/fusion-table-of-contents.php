<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 3.9
 */

?>
<script type="text/html" id="tmpl-fusion_table_of_contents-shortcode">
	<div {{{ _.fusionGetAttributes( tocAttr ) }}}>
		<div class="awb-toc-el__content"></div>
	</div>
</script>
