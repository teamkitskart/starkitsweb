<?php
/**
 * Underscore.js template.
 *
 * @package fusion-builder
 */

?>
<script type="text/template" id="tmpl-fusion_woo_order_additional_info-shortcode">
	<section {{{ _.fusionGetAttributes( elemAttr ) }}}>
		<div class="fusion-builder-placeholder-preview">
			<i class="{{ icon }}" aria-hidden="true"></i> {{ label }}
		</div>
	</section>
</script>
