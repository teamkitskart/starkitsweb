<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 3.0
 */

?>
<script type="text/html" id="tmpl-fusion_submenu-shortcode">
	<nav {{{ _.fusionGetAttributes( attr ) }}}>
		{{{ menuMarkup }}}
	</nav>
</script>
